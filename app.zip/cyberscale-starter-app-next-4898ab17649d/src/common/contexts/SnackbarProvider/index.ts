import SnackbarProvider from './SnackbarProvider';

export * from 'notistack';

export default SnackbarProvider;
