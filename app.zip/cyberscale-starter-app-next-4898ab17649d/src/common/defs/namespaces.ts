import Users from '@modules/users/defs/namespace';

const Namespaces = {
  Users,
};

export default Namespaces;
