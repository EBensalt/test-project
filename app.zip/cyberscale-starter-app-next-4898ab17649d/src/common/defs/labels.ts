import Users from '@modules/users/defs/labels';

const Labels = {
  Users,
};

export default Labels;
