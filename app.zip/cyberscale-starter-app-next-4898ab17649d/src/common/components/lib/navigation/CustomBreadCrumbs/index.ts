import CustomBreadcrumbs from './CustomBreadcrumbs';

export * from './types';

export default CustomBreadcrumbs;
