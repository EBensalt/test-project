const namespace = 'users';
export default namespace;
