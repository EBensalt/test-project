const namespace = 'posts';
export default namespace;
