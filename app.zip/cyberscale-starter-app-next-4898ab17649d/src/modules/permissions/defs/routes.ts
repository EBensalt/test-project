const prefix = '/permissions';
const Routes = {
  Forbidden: prefix + '/403',
};

export default Routes;
