<?php

return [
    'permission_denied' => 'Permission refusée',
    'unexpected_error' => 'Erreur inattendue. Contactez l\'administrateur',
    'hello' => 'Bonjour',
];
