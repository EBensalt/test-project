<?php

return [
    'not_found' => 'Utilisateur non trouvé.',
    'created' => 'Utilisateur créé.',
    'updated' => 'Utilisateur mis à jour.',
    'deleted' => 'Utilisateur supprimé.',
];
