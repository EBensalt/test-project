<?php

return [
    'not_found' => 'Téléchargement non trouvé.',
    'created' => 'Téléchargement créé.',
    'updated' => 'Téléchargement mis à jour.',
    'deleted' => 'Téléchargement supprimé.',
];
