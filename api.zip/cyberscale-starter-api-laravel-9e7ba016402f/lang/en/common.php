<?php

return [
    'permission_denied' => 'Permission denied',
    'unexpected_error' => 'Unexpected error. Contact the administrator.',
    'hello' => 'Hello',
];
