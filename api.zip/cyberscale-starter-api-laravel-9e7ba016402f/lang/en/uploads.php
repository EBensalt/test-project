<?php

return [
    'not_found' => 'Upload not found.',
    'created' => 'Upload created.',
    'updated' => 'Upload updated.',
    'deleted' => 'Upload deleted.',
];
