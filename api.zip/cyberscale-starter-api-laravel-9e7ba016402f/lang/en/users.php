<?php

return [
    'not_found' => 'User not found.',
    'created' => 'User created.',
    'updated' => 'User updated.',
    'deleted' => 'User deleted.',
];
