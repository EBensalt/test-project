<?php

namespace App\Enums;

enum LinkOperator: string
{
    case AND = 'and';
    case OR = 'or';
}
