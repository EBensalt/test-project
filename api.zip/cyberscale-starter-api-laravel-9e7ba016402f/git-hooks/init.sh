#!/bin/sh
cp git-hooks/pre-commit .git/hooks/pre-commit